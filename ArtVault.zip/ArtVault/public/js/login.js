document.addEventListener('DOMContentLoaded', function () {
  const loginModal = new bootstrap.Modal(document.getElementById('loginModal'), {
    backdrop: 'static',  // Impede que o modal feche ao clicar fora
    keyboard: false      // Impede que o modal feche ao pressionar "Esc"
  });
  loginModal.show();
});

// Importa o Firebase e os métodos de autenticação
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAD3sW_0GTuJJqCvI4UvILrgFYmnyNbT5E",
  authDomain: "projeto-artvault.firebaseapp.com",
  projectId: "projeto-artvault",
  storageBucket: "projeto-artvault.firebasestorage.app",
  messagingSenderId: "544194557531",
  appId: "1:544194557531:web:62990cb986cc29ecadb17e",
  measurementId: "G-KY0YM6TB48"
};

// Inicializa o Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Autenticação com Google
const googleProvider = new GoogleAuthProvider();
document.getElementById('login-google').addEventListener('click', () => {
  signInWithPopup(auth, googleProvider)
    .then((result) => {
      window.location.href = "galeria.html"; // Redireciona para outra página após login
    })
    .catch((error) => {
      console.error("Erro no login com Google:", error);
    });
});



// Autenticação com E-mail e Senha, criação de conta
document.getElementById('email-create-form').addEventListener('click', () => {
  const emailField = document.getElementById("email");
  const passwordField = document.getElementById("password");

  const email = emailField.value;
  const password = passwordField.value;

  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      alert("Usuário criado com sucesso!");

      // Limpa os campos após o sucesso
      emailField.value = "";
      passwordField.value = "";
    })
    .catch((error) => {
      alert("Erro: " + error.message);

      // Limpa os campos após erro, se desejado
      emailField.value = "";
      passwordField.value = "";
    });
});

// Autenticação com E-mail e Senha, realizar login 
function loginUser() {
  const emailField = document.getElementById("email");
  const passwordField = document.getElementById("password");

  const email = emailField.value;
  const password = passwordField.value;

  signInWithEmailAndPassword(auth, email, password)
    .then(() => {
      window.location.href = "galeria.html"; // Redireciona após o login
    })
    .catch((error) => {
      alert("Erro: " + error.message);
    });
}

// Realizar login ao clicar no botão
document.getElementById('email-login').addEventListener('click', () => {
  loginUser();
});

// Realizar login ao pressionar "Enter" no campo de senha
document.getElementById("password").addEventListener('keydown', (event) => {
  if (event.key === "Enter") {
    loginUser();
  }
});