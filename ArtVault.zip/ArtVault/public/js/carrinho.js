// Importa o Firebase, Firestore e Auth
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getFirestore, doc, setDoc, collection, addDoc, getDocs, deleteDoc, updateDoc, query, where } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAD3sW_0GTuJJqCvI4UvILrgFYmnyNbT5E",
  authDomain: "projeto-artvault.firebaseapp.com",
  projectId: "projeto-artvault",
  storageBucket: "projeto-artvault.firebasestorage.app",
  messagingSenderId: "544194557531",
  appId: "1:544194557531:web:62990cb986cc29ecadb17e",
  measurementId: "G-KY0YM6TB48"
};

// Inicializa o Firebase, Firestore e Auth
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Limite máximo de itens no carrinho
const LIMITE_CARRINHO = 20;

// Função para atualizar o carrinho e exibir no modal
async function atualizarCarrinho(userUID) {
  const carrinhoRef = collection(db, `users/${userUID}/carrinho`);
  const carrinhoSnapshot = await getDocs(carrinhoRef);

  const cartItemsContainer = document.getElementById("cart-items");
  cartItemsContainer.innerHTML = ""; // Limpa o conteúdo atual

  let total = 0;
  let itemCount = 0; // Contador de itens no carrinho

  carrinhoSnapshot.forEach(doc => {
    const item = doc.data();
    total += item.preco * item.quantidade;
    itemCount += item.quantidade;

    // Cria o HTML para exibir o item no modal
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `
      <img src="${item.imagem}" alt="${item.nome}" class="card-img-top">
      <div class="item-details">
        <span class="item-name">${item.nome}</span>
        <span class="item-quantity">Qtd: ${item.quantidade}</span>
        <span class="item-value">R$ ${item.preco.toFixed(2)}</span>
      </div>
      <button class="btn-remove" data-id="${doc.id}">
        <i class="fas fa-trash-can"></i>
      </button>
    `;

    cartItemsContainer.appendChild(li);

    // Adiciona o event listener para o botão de remoção
    const removeButton = li.querySelector(".btn-remove");
    removeButton.addEventListener("click", () => {
      removerItemDoCarrinho(userUID, doc.id);
    });
  });

  // Atualiza o contador de itens no carrinho
  document.getElementById("cart-count").innerText = itemCount;

  // Exibe o total no carrinho
  document.getElementById("cart-total").innerText = `Total: R$ ${total.toFixed(2)}`;
}

// Função para remover item do carrinho
async function removerItemDoCarrinho(userUID, itemId) {
  try {
    const itemRef = doc(db, `users/${userUID}/carrinho/${itemId}`);
    await deleteDoc(itemRef);

    // Atualiza o carrinho e contador após a remoção
    await atualizarCarrinho(userUID);

    // Verifica se o contador de itens está vazio e fecha o modal
    const itemCount = document.getElementById("cart-count").innerText;
    if (parseInt(itemCount) === 0) {
      const modal = document.getElementById("cart-modal");
      modal.classList.remove("show");
      document.body.style.overflow = ''; // Libera o scroll da página
    }
  } catch (error) {
    console.error('Erro ao remover item do carrinho:', error);
  }
}



// Função para verificar o limite do carrinho
async function verificarLimiteCarrinho(userUID) {
  const carrinhoRef = collection(db, `users/${userUID}/carrinho`);
  const carrinhoSnapshot = await getDocs(carrinhoRef);

  let itemCount = 0;
  carrinhoSnapshot.forEach(doc => {
    const item = doc.data();
    itemCount += item.quantidade;
  });
  
  return itemCount < LIMITE_CARRINHO;
}

// Função para adicionar ou atualizar quantidade de um item no carrinho
async function adicionarOuAtualizarItemNoCarrinho(userUID, nome, preco, imagem) {
  const carrinhoRef = collection(db, `users/${userUID}/carrinho`);
  const itemQuery = query(carrinhoRef, where("nome", "==", nome), where("preco", "==", preco));
  const itemSnapshot = await getDocs(itemQuery);

  if (!itemSnapshot.empty) {
    // Se o item já existe, atualiza a quantidade
    const itemDoc = itemSnapshot.docs[0];
    const itemData = itemDoc.data();
    const novaQuantidade = itemData.quantidade + 1;

    await updateDoc(itemDoc.ref, { quantidade: novaQuantidade });
  } else {
    // Se o item não existe, adiciona-o como novo com quantidade inicial 1
    await addDoc(carrinhoRef, { nome, preco, imagem, quantidade: 1, timestamp: new Date() });
  }

  // Atualiza a interface
  atualizarCarrinho(userUID);
}

// Função para finalizar a compra
async function finalizarCompra(userUID) {
  const carrinhoRef = collection(db, `users/${userUID}/carrinho`);
  const pedidosRef = collection(db, `users/${userUID}/pedidos`);
  
  const carrinhoSnapshot = await getDocs(carrinhoRef);

  if (carrinhoSnapshot.empty) {
    alert("O carrinho está vazio!");
    return;
  }

  // Cria um novo pedido com os itens do carrinho
  const pedidoData = {
    items: [],
    total: 0,
    timestamp: new Date()
  };

  carrinhoSnapshot.forEach(doc => {
    const item = doc.data();
    pedidoData.items.push(item);
    pedidoData.total += item.preco * item.quantidade;
  });

  // Adiciona o pedido na coleção de pedidos
  await addDoc(pedidosRef, pedidoData);

  // Limpa o carrinho após finalizar a compra
  const deletePromises = carrinhoSnapshot.docs.map(doc => deleteDoc(doc.ref));
  await Promise.all(deletePromises);

  // Atualiza o contador do carrinho e o modal
  atualizarCarrinho(userUID);
  alert("Compra finalizada com sucesso! Seu pedido foi registrado.");

  // Fecha o modal automaticamente após finalizar a compra
  const modal = document.getElementById("cart-modal");
  modal.classList.remove("show");
}

// Abre o modal e carrega os itens do carrinho
document.getElementById('verCarrinho').addEventListener('click', async () => {
  const user = auth.currentUser;
  
  if (user) {
    // Carrega o carrinho do Firestore para verificar se está vazio
    const carrinhoRef = collection(db, `users/${user.uid}/carrinho`);
    const carrinhoSnapshot = await getDocs(carrinhoRef);

    if (carrinhoSnapshot.empty) {
      // Exibe alerta se o carrinho está vazio e não abre o modal
      alert("O carrinho está vazio!");
    } else {
      // Se o carrinho não estiver vazio, atualiza o conteúdo e exibe o modal
      await atualizarCarrinho(user.uid);
      const modal = document.getElementById("cart-modal");
      modal.classList.add("show");
    }
  }
});

// Fecha o modal com animação suave
document.getElementById('fecharCarrinho').addEventListener('click', () => {
  const modal = document.getElementById("cart-modal");
  modal.classList.remove("show");
});

document.addEventListener('DOMContentLoaded', () => {
  // Verifica o estado de autenticação do usuário ao carregar a página
  onAuthStateChanged(auth, (user) => {
    if (user) {
      const userUID = user.uid;
      const userEmail = user.email;

      // Armazena o email do usuário no Firestore, caso ainda não esteja salvo
      const userDocRef = doc(db, `users/${userUID}`);
      setDoc(userDocRef, { email: userEmail }, { merge: true });

      // Atualiza o carrinho e o contador automaticamente ao fazer login
      atualizarCarrinho(userUID);

      // Seleciona todos os botões com a classe 'btn-add' e adiciona o evento de clique
      document.querySelectorAll('.btn-add').forEach(button => {
        button.addEventListener('click', async (event) => {

          // Verifica se o carrinho já atingiu o limite de 20 itens
          const podeAdicionar = await verificarLimiteCarrinho(userUID);
          if (!podeAdicionar) {
            alert("O carrinho atingiu o limite de 20 itens!");
            return;
          }

          // Obtém os atributos de dados do botão
          const nome = event.target.getAttribute('data-nome');
          const preco = parseFloat(event.target.getAttribute('data-preco'));
          const imagem = event.target.getAttribute('data-imagem');

          try {
            // Adiciona ou atualiza a quantidade do item no carrinho
            await adicionarOuAtualizarItemNoCarrinho(userUID, nome, preco, imagem);
          } catch (error) {
            console.error('Erro ao adicionar ou atualizar item no Firestore:', error);
          }
        });
      });

      // Adiciona o evento ao botão de finalizar compra
      document.getElementById('finalizarCompra').addEventListener('click', () => {
        finalizarCompra(userUID);
      });

    } else {
      // Limpa o contador de itens no carrinho quando o usuário desloga
      document.getElementById("cart-count").innerText = 0;
      console.log("Usuário não autenticado. É necessário fazer login para adicionar ao carrinho.");
    }
  });
});

