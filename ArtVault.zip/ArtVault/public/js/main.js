// Referências aos elementos do modal
const cartModal = document.getElementById('cart-modal');
const cartItemsContainer = document.querySelector('.cart-items-container');

// Função para bloquear rolagem da página
function preventPageScroll(e) {
  e.preventDefault();
  e.stopPropagation();
}

// Função para habilitar rolagem no carrinho (com rolagem suave)
function enableCartScroll() {
  let lastTime = 0; // Variável para controlar o tempo entre os eventos de rolagem
  const smoothnessFactor = 0.4; // Fator de suavização (ajuste conforme necessário)
  
  cartItemsContainer.addEventListener('wheel', (e) => {
    const currentTime = Date.now();

    // Para evitar a rolagem excessiva rápida, aplicamos um fator de suavização
    if (currentTime - lastTime > 50) {  // Limita a frequência de rolagem
      lastTime = currentTime;
      
      const scrollAmount = e.deltaY * smoothnessFactor; // Suaviza o movimento da rolagem
      cartItemsContainer.scrollTop += scrollAmount; // Movimenta o scroll do carrinho
      e.preventDefault(); // Impede a rolagem da página
    }
  });
}

// Bloqueio de rolagem da página quando o modal estiver aberto
cartModal.addEventListener('mouseenter', () => {
  document.body.style.overflow = 'hidden'; // Bloqueia o scroll da página
});

// Libera a rolagem da página quando o modal for fechado
cartModal.addEventListener('mouseleave', () => {
  document.body.style.overflow = ''; // Libera o scroll da página
});

// Impede a rolagem da página por padrão
cartModal.addEv


